(() => {
  const bookElement = document.getElementById("book");
  const status = document.getElementById("page-status");
  const previousButton = document.getElementById("prev");
  const nextButton = document.getElementById("next");

  if (!window.St || !window.St.PageFlip) {
    status.textContent = "Dergi yüklenemedi";
    return;
  }

  const pageFlip = new St.PageFlip(bookElement, {
    width: 400,
    height: 560,
    size: "stretch",
    minWidth: 280,
    maxWidth: 800,
    minHeight: 390,
    maxHeight: 1120,
    showCover: true,
    drawShadow: true,
    flippingTime: 850,
    usePortrait: true,
    mobileScrollSupport: true,
    maxShadowOpacity: 0.22,
    autoSize: true
  });

  pageFlip.loadFromHTML(document.querySelectorAll("#book .page"));

  function updateStatus() {
    const current = pageFlip.getCurrentPageIndex();
    const total = pageFlip.getPageCount();
    status.textContent = current === 0 ? "Kapak" : `${current + 1} / ${total}`;
    previousButton.disabled = current <= 0;
    nextButton.disabled = current >= total - 1;
    previousButton.style.opacity = previousButton.disabled ? ".45" : "1";
    nextButton.style.opacity = nextButton.disabled ? ".45" : "1";
  }

  pageFlip.on("flip", updateStatus);
  previousButton.addEventListener("click", () => pageFlip.flipPrev());
  nextButton.addEventListener("click", () => pageFlip.flipNext());
  document.addEventListener("keydown", (event) => {
    if (event.key === "ArrowLeft") pageFlip.flipPrev();
    if (event.key === "ArrowRight") pageFlip.flipNext();
  });
  updateStatus();
})();
