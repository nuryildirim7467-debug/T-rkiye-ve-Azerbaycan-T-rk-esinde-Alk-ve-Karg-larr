ALKIŞ VE KARGIŞLAR — DİJİTAL DERGİ TASLAĞI

Dosyalar:
- index.html: içerik ve sayfa yapısı
- style.css: akademik dergi tasarımı
- script.js: sayfa çevirme ve düğmeler

ÖNCE BİLGİSAYARDA DENEME
1. Üç dosyayı aynı klasörde tutun.
2. index.html dosyasını Chrome veya Edge'de açın.
3. Sayfa çevirme kütüphanesi CDN üzerinden yüklendiği için internet bağlantısı gerekir.

İNTERNETTE YAYIMLAMA (GitHub Pages)
1. GitHub hesabı açın ve yeni bir public repository oluşturun; örneğin alkis-kargis-dergisi.
2. index.html, style.css ve script.js dosyalarını repository ana dizinine yükleyin.
3. Repository Settings > Pages bölümünü açın.
4. Build and deployment altında Deploy from a branch seçin.
5. Branch olarak main, klasör olarak /(root) seçip kaydedin.
6. GitHub Pages bir URL verdiğinde o adresi farklı cihazdan ve mobil internetten test edin.
7. Son olarak URL'yi QR kod aracına girin ve QR kodu üretin.

ÖNEMLİ
- İçerikteki alkış ve kargış örnekleri başlangıç taslağıdır. TÜBİTAK projesine eklemeden önce her ifadeyi güvenilir sözlük, folklor derlemesi veya akademik kaynakla doğrulayın.
- Kaynakçada yazar, eser adı, yayın yılı ve sayfa numarasını ekleyin.
- GitHub Pages ücretsiz barındırma sunabilir; hizmet koşulları değişebilir.
- Bu proje CDN ve Google Fonts kullandığından sayfa çevirme kütüphanesi ve yazı tipleri için internet gerekir.
